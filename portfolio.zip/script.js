document.getElementById("contactForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const name = (document.getElementById("name")?.value || "").trim();
  const email = (document.getElementById("email")?.value || "").trim();
  const message = (document.getElementById("message")?.value || "").trim();

  if (!name || !email || !message) {
    alert("Please fill in all fields.");
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    alert("Please enter a valid email address.");
    return;
  }

  try {
    const contactData = {
      name,
      email,
      message,
      profile: {
        studentName: "Chaitra",
        rollNo: "25BCYC20",
        university: "Kristu Jayanti University",
        section: "1",
        education: "BCA Cyber Security",
        skills: ["Python", "C", "Digital Engineering"]
      },
      timestamp: new Date()
    };

    const docRef = await window.addDoc(window.collection(window.db, "contacts"), contactData);
    console.log("Document written with ID: ", docRef.id);
    alert("Thank you for your message, " + name + "! I'll get back to you soon.");
    document.getElementById("contactForm").reset();
  } catch (error) {
    console.error("Error adding document: ", error);
    alert("There was an error sending your message. Please try again.");
  }
});