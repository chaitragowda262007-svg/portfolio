document.getElementById("contactForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const nameInput = document.getElementById("name");
  const emailInput = document.getElementById("email");
  const messageInput = document.getElementById("message");

  const name = nameInput?.value?.trim() || "";
  const email = emailInput?.value?.trim() || "";
  const message = messageInput?.value?.trim() || "";

  if (!name || !email || !message) {
    alert("Please fill in all fields.");
    return;
  }

  try {
    const docRef = await window.addDoc(window.collection(window.db, "contacts"), {
      name: name,
      email: email,
      message: message,
      timestamp: new Date()
    });
    console.log("Document written with ID: ", docRef.id);
    alert("Thank you for your message, " + name + "! I'll get back to you soon.");
    document.getElementById("contactForm").reset();
  } catch (error) {
    console.error("Error adding document: ", error);
    alert("There was an error sending your message. Please try again.");
  }
});